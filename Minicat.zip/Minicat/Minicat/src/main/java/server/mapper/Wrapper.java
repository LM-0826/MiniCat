package server.mapper;

import server.Servlet;

/**
 * 包装实体类
 */
public class Wrapper {

    /**
     * URL映射
     */
    private String urlPatten;

    /**
     * Servlet对象
     */
    private Servlet servlet;

    public String getUrlPatten() {
        return urlPatten;
    }

    public void setUrlPatten(String urlPatten) {
        this.urlPatten = urlPatten;
    }

    public Servlet getServlet() {
        return servlet;
    }

    public void setServlet(Servlet servlet) {
        this.servlet = servlet;
    }

    public Wrapper(String urlPatten, Servlet servlet) {
        this.urlPatten = urlPatten;
        this.servlet = servlet;
    }

}
