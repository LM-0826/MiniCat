package server.mapper;

import java.util.ArrayList;
import java.util.List;

/**
 * 上下文内容实体类
 */
public class Context {

    /**
     * 应用请求路径
     */
    private String path;

    /**
     * 应用磁盘绝对路径
     */
    private String docBase;

    /**
     * 包装实体对象集合
     */
    private List<Wrapper> wrapperList = new ArrayList<>();

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getDocBase() {
        return docBase;
    }

    public void setDocBase(String docBase) {
        this.docBase = docBase;
    }

    public List<Wrapper> getWrapperList() {
        return wrapperList;
    }

    public void setWrapperList(List<Wrapper> wrapperList) {
        this.wrapperList = wrapperList;
    }

    public Context(String path, String docBase) {
        this.path = path;
        this.docBase = docBase;
    }

}
