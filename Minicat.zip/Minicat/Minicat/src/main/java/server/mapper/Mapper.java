package server.mapper;

import java.util.ArrayList;
import java.util.List;

/**
 * 映射实体类
 */
public class Mapper {

    /**
     * 主机实体对象集合
     */
    private List<Host> hostList = new ArrayList<>();

    public List<Host> getHostList() {
        return hostList;
    }

    public void setHostList(List<Host> hostList) {
        this.hostList = hostList;
    }

}
