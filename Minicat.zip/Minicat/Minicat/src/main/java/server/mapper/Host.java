package server.mapper;

import java.util.ArrayList;
import java.util.List;

/**
 * 主机实体类
 */
public class Host {

    /**
     * 主机名
     */
    private String name;

    /**
     * 应用部署根目录
     */
    private String appBase;

    /**
     * 上下文内容实体对象集合
     */
    private List<Context> contextList = new ArrayList<>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAppBase() {
        return appBase;
    }

    public void setAppBase(String appBase) {
        this.appBase = appBase;
    }

    public List<Context> getContextList() {
        return contextList;
    }

    public void setContextList(List<Context> contextList) {
        this.contextList = contextList;
    }

    public Host(String name, String appBase) {
        this.name = name;
        this.appBase = appBase;
    }
}
