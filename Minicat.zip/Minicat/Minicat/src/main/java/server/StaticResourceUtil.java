package server;

import server.mapper.Context;
import server.mapper.Host;
import server.mapper.Mapper;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class StaticResourceUtil {

    /**
     * 获取静态资源文件的绝对路径
     * @param path
     * @return
     */
    public static String getAbsolutePath(String path) {
        String absolutePath = StaticResourceUtil.class.getResource("/").getPath();
        return absolutePath.replaceAll("\\\\","/") + path;
    }

    /**
     * 读取静态资源文件输入流，通过输出流输出
     */
    public static void outputStaticResource(InputStream inputStream, OutputStream outputStream) throws IOException {

        int count = 0;
        while(count == 0) {
            count = inputStream.available();
        }

        int resourceSize = count;
        // 输出http请求头,然后再输出具体内容
        outputStream.write(HttpProtocolUtil.getHttpHeader200(resourceSize).getBytes());

        // 读取内容输出
        long written = 0 ;// 已经读取的内容长度
        int byteSize = 1024; // 计划每次缓冲的长度
        byte[] bytes = new byte[byteSize];

        while(written < resourceSize) {
            if(written  + byteSize > resourceSize) {  // 说明剩余未读取大小不足一个1024长度，那就按真实长度处理
                byteSize = (int) (resourceSize - written);  // 剩余的文件内容长度
                bytes = new byte[byteSize];
            }

            inputStream.read(bytes);
            outputStream.write(bytes);

            outputStream.flush();
            written+=byteSize;
        }
    }

    /**
     * 根据url和映射实体对象获得上下文内容对象
     * @param urlArr 分割后的url
     * @param mapper 映射实体对象
     * @return
     */
    public static Context getContext(String[] urlArr, Mapper mapper) {
        //1.根据请求路径的主机名匹配主机实例对象
        if(mapper.getHostList() == null || mapper.getHostList().isEmpty()) {
            return null;
        }
        for (int i = 0; i < mapper.getHostList().size(); i++) {
            Host host = mapper.getHostList().get(i);
            if (host.getName().equals(urlArr[0])) {
                //2.匹配中请求路径的项目名匹配Context并返回
                if (host.getContextList() == null || host.getContextList().isEmpty()) {
                    return null;
                }
                for (int j = 0; j < host.getContextList().size(); j++) {
                    Context context = host.getContextList().get(j);
                    if (context.getPath().equals(urlArr[1])) {
                        return context;
                    }
                }
            }
        }
        return null;
    }

}
