package server;

import server.mapper.Context;
import server.mapper.Mapper;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * 封装Response对象，需要依赖于OutputStream
 *
 * 该对象需要提供核心方法，输出html
 */
public class Response {

    private OutputStream outputStream;

    public Response() {
    }

    public Response(OutputStream outputStream) {
        this.outputStream = outputStream;
    }


    // 使用输出流输出指定字符串
    public void output(String content) throws IOException {
        outputStream.write(content.getBytes());
    }

    /**
     * 输出静态资源文件的方法 : 要根据url来获取到静态资源的绝对路径，进一步根据绝对路径读取该静态资源文件，最终通过输出流输出
     * @param urlArr 分割后的url数组
     * @param mapper 映射实体对象
     * @throws IOException
     */
    public void outputHtml(String[] urlArr, Mapper mapper) throws IOException {
        //1.获得Context
        Context context = StaticResourceUtil.getContext(urlArr, mapper);
        if(context != null && context.getWrapperList() != null && !context.getWrapperList().isEmpty()) {
            //2.获得Context的磁盘路径
            String docBase = context.getDocBase();
            File[] files = new File(docBase).listFiles();
            for (int i = 0; i < files.length; i++) {
                if(files[i].getName().equals(urlArr[urlArr.length - 1]) && files[i].exists() && files[i].isFile()) {
                    // 读取静态资源文件，输出静态资源
                    StaticResourceUtil.outputStaticResource(new FileInputStream(files[i]), outputStream);
                }
            }
        } else {
            //3.如果没有找到资源输出404
            output(HttpProtocolUtil.getHttpHeader404());
        }
    }

}
